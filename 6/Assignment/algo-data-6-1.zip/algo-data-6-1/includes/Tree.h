#pragma once
#include "Node.h"

Node initTree(Node *n);
void add(Node *n, int x);
void terminateTree(Node *n);